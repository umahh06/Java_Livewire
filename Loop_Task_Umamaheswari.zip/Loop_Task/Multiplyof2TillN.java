package Loop_Task;

import java.util.Scanner;

public class Multiplyof2TillN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter The Number:");
		int a = sc.nextInt();
		int n = 2;
		while(n<=a) {
			System.out.println(n);
			n = n+2;
			
		}
		

	}

}
