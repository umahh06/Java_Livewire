package Loop_Task;

import java.util.Scanner;

public class Multiplyof2or3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int a = sc.nextInt();
		
		for(int i = 0;i<=a;i++) {
			if(i%2==0 || i%3==0) {
				System.out.println(i);
			}
		}

	}

}
