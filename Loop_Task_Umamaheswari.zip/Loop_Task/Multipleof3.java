package Loop_Task;

import java.util.Scanner;

public class Multipleof3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Number: ");
		int a = sc.nextInt();
		
		for(int i = 1;i <=a;i++) {
			System.out.println(i*3);
		}
		
	}

}
