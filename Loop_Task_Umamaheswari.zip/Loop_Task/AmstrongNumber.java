package Loop_Task;

public class AmstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int y = 122;
		int x= y;
		int z=y;
		int digit=0;
		
		while(y>0) {
			y=y/10;
			digit++;
		}
		int sum = 0;
		while(x>0) {
			int rem = x%10;
			sum = sum+(int)(Math.pow(rem, digit));
			x=x/10;
		}
		if(z==sum) {
			System.out.println("Amstrong number");
		}else {
			System.out.println("Not Amstrong Number");
		}
		

	}

}
