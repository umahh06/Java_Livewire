package Loop_Task;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "mom";
		String t =" ";
		for(int i =s.length()-1;i>=0;i--) {
			t= t+s.charAt(i);
		}
		if(s.equalsIgnoreCase(t)) {
			System.out.println("Palimdrome");
		}
		else {
			System.out.println("Not Palindrome");
		}

	}

}
