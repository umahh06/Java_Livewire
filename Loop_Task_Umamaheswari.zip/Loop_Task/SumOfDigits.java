package Loop_Task;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter The Numbers: ");
		int a = sc.nextInt();
		int sum = 0;
		while(a>0) {
			int b = a%10;
			sum = sum+b;
			a/=10;
		}
		System.out.println("sum of digits:"+sum);
		

	}

}
