package Loop_Task;

import java.util.Scanner;

public class CountDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter The Number:");
		int a = sc.nextInt();
		int count = 1;
		for(int i = 1;i<=a;i++) {
//			System.out.println(i);
			count++;
			
		}
		System.out.println("The Total Digits:" +count);
		}

}
