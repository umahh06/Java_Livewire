package Loop_Task;

import java.util.Scanner;

public class NaturalNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:");
		int no = sc.nextInt();
		
		for(int i=1;i<=no;i++) {
			System.out.println(i);
		}

		
	}

}
