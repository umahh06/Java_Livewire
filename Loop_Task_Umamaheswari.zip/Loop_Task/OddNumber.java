package Loop_Task;

import java.util.Scanner;

public class OddNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number: ");
		int a = sc.nextInt();
		int count = 0;
		for(int i = 1;i<=a*2;i+=2) {
			System.out.println(i);
			count+=1;
			
		}
		System.out.println("the total digits are "+count);
		

	}

}
