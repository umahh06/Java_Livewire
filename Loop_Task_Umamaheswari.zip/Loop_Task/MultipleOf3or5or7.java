package Loop_Task;

import java.util.Scanner;

public class MultipleOf3or5or7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int a = sc.nextInt();
		
		for(int i = 1;i<a*2;i++) {
			if(i%5==0 || i%3==0 || i%7==0) {
				System.out.println(i);
			}
		}

	}

}
