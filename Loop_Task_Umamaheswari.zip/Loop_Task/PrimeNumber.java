package Loop_Task;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n = sc.nextInt();
	
		boolean isPrime = true;

		for(int i = 2; i < n; i++) {
		    if(n % i == 0) {
		        isPrime = false;
		        break;
		    }
		}

		if(isPrime)
		    System.out.println("Yes");
		else
		    System.out.println("No");

	}

}
