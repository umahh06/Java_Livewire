package Loop_Task;

import java.util.Scanner;

public class EvenNumberorOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter The Numbers: ");
		int a = sc.nextInt();
		
		int even=0;
		int odd =0;
		for(int i =1;i<=a;i++) {
			if(i%2==0) {
				even = even+i;
			}
			else {
				odd = odd+i;
			}
		}
		System.out.println("Sum of Even Numbers:"+even);
		System.out.println("Sum of Odd Numbers:"+odd);
	}

}
