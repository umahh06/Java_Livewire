package Loop_Task;

import java.util.Scanner;

public class EvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int number = sc.nextInt();
		for(int i=0;i<=number;i++) {
			System.out.println(2*i);
		}
		
	}

}
