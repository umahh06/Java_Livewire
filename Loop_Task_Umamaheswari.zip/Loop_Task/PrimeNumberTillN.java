package Loop_Task;

public class PrimeNumberTillN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 15;

		for(int i = 2; i <= n; i++) {   
		    int count = 0;

		    for(int j = 1; j <= i; j++) {  
		        if(i % j == 0) {
		            count++;
		        }
		    }

		    if(count == 2) {   
		        System.out.print(i + " ");
		    }
		}

	}

}
