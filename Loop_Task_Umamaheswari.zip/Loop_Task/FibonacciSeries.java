
package Loop_Task;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
//		int a = sc.nextInt();
		int a = 0 ;
		int b = 1 ;
		int c = 0;
		int d = 17;
		System.out.print(a+" "+b+" ");
		// 0 1 1 2 3 5 8 13 
		while(c<d) {
			c = a+b;
			if(c<=d) {
				System.out.print(c+" ");
			}	
			a=b;
			b=c;
		}
		
		
		

	}

}
